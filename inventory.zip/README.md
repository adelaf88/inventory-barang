# php-simple-inventory
Aplikasi sederhana berbasis web untuk manajemen arus inventory barang di sebuah perusahaan. 
